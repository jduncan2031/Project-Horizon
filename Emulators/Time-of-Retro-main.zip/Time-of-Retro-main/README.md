# 🎮 Time of Retro

> *The past never felt this smooth.*

A free, open-source multi-console emulator that runs entirely in your browser.
No downloads. No installs. Just pure nostalgia.

---

## 🕹️ Supported Consoles

| Console | Extensions |
|---|---|
| Game Boy Advance | `.gba` |
| Game Boy / Game Boy Color | `.gb` `.gbc` |
| NES | `.nes` |
| SNES | `.smc` `.sfc` |
| Nintendo 64 | `.z64` `.n64` |
| PlayStation 1 | `.bin` `.cue` `.iso` |
| Sega Genesis | `.md` `.gen` `.bin` |

> More consoles coming soon.

---

## ✨ Features

- 🎯 Multi-console support — one hub for all your classics
- 📂 Drag and drop ROM loading — just drop your file and play
- 💾 Save states — 4 slots per game with thumbnail previews
- ⚡ Speed control — play at 0.5×, 1×, 2×, or 4× speed
- 🔊 Volume control and mute toggle
- 📸 Screenshot — capture and download any moment
- ⌨️ Keyboard shortcuts for everything
- 📱 Mobile responsive with touch support
- 🎨 Retro-futuristic UI — dark arcade cabinet meets holographic HUD
- 🔒 100% client-side — your ROMs never leave your device

---

## 🚀 How to Use

1. Open the site in Chrome, Firefox, or Edge
2. Select your console from the grid
3. Click **Load ROM** or drag and drop your `.rom` file
4. Play!

> ⚠️ Time of Retro does not provide or distribute ROM files.
> Only use ROMs of games you legally own.

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|---|---|
| Arrow Keys | D-Pad |
| `Z` | A button |
| `X` | B button |
| `Enter` | Start |
| `Shift` | Select |
| `A` | L button |
| `S` | R button |
| `F1` | Save State |
| `F2` | Load State |
| `F` | Fullscreen |
| `M` | Mute / Unmute |

---

## 🛠️ Tech Stack

- Vanilla HTML, CSS, JavaScript — no frameworks, no build tools
- [EmulatorJS](https://emulatorjs.org) — emulation core (mGBA, Mupen64Plus, PCSX, and more)
- Web Audio API — audio output
- IndexedDB / localStorage — save states and settings
- CSS animations — retro CRT effects, scanlines, neon glow

---

## 📁 Project Structure


---

## 🗺️ Roadmap

- [x] GBA emulation
- [x] Multi-console selector
- [x] Save states with thumbnails
- [x] Speed control
- [x] Screenshot capture
- [ ] Gamepad / controller support
- [ ] Game Boy Advance link cable simulation
- [ ] Nintendo DS
- [ ] More Sega consoles (Game Gear, Saturn)
- [ ] Cloud save sync
- [ ] Game library with cover art
- [ ] CRT shader toggle

---

## ⚖️ Legal

Time of Retro does not host, distribute, or endorse piracy of any kind.
All emulation cores are open-source projects used under their respective licenses.
Users are responsible for ensuring they have the legal right to use any ROM files they load.

EmulatorJS is licensed under [GPL-3.0](https://github.com/EmulatorJS/EmulatorJS/blob/main/LICENSE).

---

## 🤝 Contributing

Pull requests are welcome! If you find a bug or want to add a feature,
open an issue first so we can discuss it.

---

<p align="center">
  Made with ❤️ for the love of retro gaming
  <br/>
  <i>The past never felt this smooth.</i>
</p>
