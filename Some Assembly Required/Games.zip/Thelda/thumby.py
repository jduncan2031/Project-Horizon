import board
import displayio
import waveshare_amoled
from adafruit_focaltouch import Adafruit_FocalTouch

# 1. Initialize Waveshare Hardware
amoled = waveshare_amoled.AMOLED_206()
amoled.setup()

# 2. Setup Display Scaling (72x40 -> 410x502)
# We use a scale of 5 to make the pixels chunky and visible
main_group = displayio.Group(scale=5)
board.DISPLAY.root_group = main_group

# 3. Setup Touchscreen for "Virtual Buttons"
i2c = board.I2C() # Uses default SCL/SDA pins
touch = Adafruit_FocalTouch(i2c, address=0x38)

# 4. Thumby API Emulation
class Display:
    def fill(self, color): pass # AMOLED handles this via displayio
    def show(self): pass
    def drawText(self, text, x, y, color):
        print(f"Game says: {text}") # Basic console debug

display = Display()

def get_touch():
    """Helper to get current touch coordinates safely"""
    try:
        t = touch.touches
        if t:
            return t[0] # Returns the first finger detected
    except:
        pass
    return None

def buttonA():
    # Right side of screen
    p = get_touch()
    return p and p['x'] > 250

def buttonB():
    # Top Right corner
    p = get_touch()
    return p and p['x'] > 250 and p['y'] < 150

def dpad_up():
    # Top Left quadrant
    p = get_touch()
    return p and p['x'] < 180 and p['y'] < 180

def dpad_down():
    # Bottom Left quadrant
    p = get_touch()
    return p and p['x'] < 180 and p['y'] > 320

def dpad_left():
    # Middle Left edge
    p = get_touch()
    return p and p['x'] < 100 and (180 <= p['y'] <= 320)

def dpad_right():
    # Center-ish Left (to the right of dpad_left)
    p = get_touch()
    return p and (100 <= p['x'] <= 200) and (180 <= p['y'] <= 320)
    # This 'fakes' the audio system so the game doesn't crash


class Audio:
    def play(self, freq, duration):
        pass # Do nothing
    def playBlocking(self, freq, duration):
        pass # Do nothing
    def stop(self):
        pass # Do nothing

audio = Audio()

